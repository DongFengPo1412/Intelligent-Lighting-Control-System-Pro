"""Unit tests for Jetson Nano Python client modules."""
import json
import os
import sys
import unittest

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from protocol import (
    BIN_FULL_FRAME,
    CommandBuilder,
    crc16_ccitt,
    pack_binary_frame,
)
from canvas_stream import (
    generate_bouncing_ball,
    generate_color_wave,
    FireSimulation,
    MatrixRainAnimation,
)
from uart_transport import JetsonUartTransport
from vision_mapping import VisionMapper


class TestJetsonProtocol(unittest.TestCase):
    def test_crc16(self):
        data = b"hello world"
        # Matches binascii.crc_hqx
        self.assertEqual(crc16_ccitt(data), 0xEFEB)

    def test_binary_header_pack(self):
        payload = b"\x00\x01\x02" * 256  # 768 bytes
        packet = pack_binary_frame(
            frame_type=BIN_FULL_FRAME,
            frame_seq=42,
            payload=payload,
            offset=0,
            commit_now=True,
            auto_mode=True,
        )
        self.assertEqual(len(packet), 16 + 768)
        self.assertEqual(packet[0:4], b"\x55\xaa\x43\x46")
        self.assertEqual(packet[4], BIN_FULL_FRAME)
        self.assertEqual(packet[5], 1)  # Version

    def test_command_builder(self):
        ping_json = json.loads(CommandBuilder.ping(req_id="p1"))
        self.assertEqual(ping_json["cmd"], "ping")
        self.assertEqual(ping_json["req_id"], "p1")

        track_json = json.loads(CommandBuilder.track(0.3, 0.7, visible=True, conf=0.95))
        self.assertEqual(track_json["cmd"], "track")
        self.assertAlmostEqual(track_json["x"], 0.3)
        self.assertAlmostEqual(track_json["y"], 0.7)

        hand_json = json.loads(CommandBuilder.hand(0.5, 0.5, -0.1, pinch=True))
        self.assertEqual(hand_json["cmd"], "hand")
        self.assertTrue(hand_json["pinch"])

        arcade_in = json.loads(CommandBuilder.arcade_input(down=2, pressed=2))
        self.assertEqual(arcade_in["action"], "input")
        self.assertEqual(arcade_in["down"], 2)


class TestCanvasGenerators(unittest.TestCase):
    def test_color_wave(self):
        pixels = generate_color_wave(1.0)
        self.assertEqual(len(pixels), 256)
        for r, g, b in pixels:
            self.assertTrue(0 <= r <= 255)
            self.assertTrue(0 <= g <= 255)
            self.assertTrue(0 <= b <= 255)

    def test_bouncing_ball(self):
        pixels = generate_bouncing_ball(2.5)
        self.assertEqual(len(pixels), 256)

    def test_matrix_rain(self):
        sim = MatrixRainAnimation()
        pixels = sim.step()
        self.assertEqual(len(pixels), 256)

    def test_fire_sim(self):
        sim = FireSimulation()
        pixels = sim.step()
        self.assertEqual(len(pixels), 256)


class TestVisionMapper(unittest.TestCase):
    def setUp(self):
        self.transport = JetsonUartTransport(simulate=True)
        self.transport.connect()
        self.mapper = VisionMapper(self.transport, {
            "gesture_mappings": {
                "1": {"action": "mode", "value": 1},
                "2": {"action": "mode", "value": 2},
            }
        })

    def test_gesture_mode_dispatch(self):
        self.mapper.handle_gesture("1")
        self.mapper.handle_gesture("2")

    def test_hand_loss_key_release(self):
        # Hand visible
        self.mapper.handle_hand_frame(visible=True, x=0.5, y=0.5, mode="arcade")
        self.assertTrue(self.mapper.last_hand_visible)

        # Hand lost -> should trigger release
        self.mapper.handle_hand_frame(visible=False, mode="arcade")
        self.assertFalse(self.mapper.last_hand_visible)
        self.assertEqual(self.mapper.last_arcade_keys, 0)


class TestCanvasStreamerAck(unittest.TestCase):
    def test_uart_transport_alias(self):
        from uart_transport import UartTransport, JetsonUartTransport
        self.assertIs(UartTransport, JetsonUartTransport)

    def test_streamer_ack_distinction(self):
        from canvas_stream import CanvasStreamer

        class FakeTransport:
            def __init__(self, reply):
                self.reply = reply
            def send_raw_with_ack(self, pkt, expected_frame_seq, timeout=1.0):
                return self.reply
            def send_line(self, line, wait_reply=True, timeout=1.0):
                return self.reply

        # When overridden by user manual control
        tr_overridden = FakeTransport({"status": "ok", "committed": True, "displayed": False, "mode_overridden": True})
        st1 = CanvasStreamer(tr_overridden)
        dummy_colors = [(0, 0, 0)] * 256
        ok1 = st1.send_binary_frame(dummy_colors, auto_mode=True, require_displayed=False)
        self.assertTrue(ok1)
        self.assertTrue(st1.is_committed)
        self.assertFalse(st1.is_displayed)
        self.assertTrue(st1.is_overridden)

        # When actively rendered to matrix
        tr_displayed = FakeTransport({"status": "ok", "committed": True, "displayed": True, "mode_overridden": False})
        st2 = CanvasStreamer(tr_displayed)
        ok2 = st2.send_binary_frame(dummy_colors, auto_mode=True, require_displayed=True)
        self.assertTrue(ok2)
        self.assertTrue(st2.is_displayed)
        self.assertFalse(st2.is_overridden)

    def test_streamer_lifecycle_start_and_stop(self):
        from canvas_stream import CanvasStreamer

        class ScriptedTransport:
            def __init__(self):
                self.lines_sent = []
                self.raw_sent = []
            def send_line(self, line, wait_reply=True, timeout=1.0):
                self.lines_sent.append(line)
                parsed = json.loads(line)
                act = parsed.get("action")
                if act == "start":
                    return {"status": "ok", "active": True, "session_id": parsed.get("session_id", "")}
                elif act == "ping":
                    return {"status": "ok", "active": True}
                elif act == "stop":
                    return {"status": "ok", "session_state": "stopped"}
                return {"status": "ok"}
            def send_raw_with_ack(self, pkt, expected_frame_seq, timeout=1.0):
                self.raw_sent.append(pkt)
                return {"status": "ok", "type": "bin_frame", "frame_id": expected_frame_seq, "committed": True, "displayed": True}

        tr = ScriptedTransport()
        st = CanvasStreamer(tr)
        # 1. Start session
        started = st.start(session_id="test_sess_01", initial_seq=10, heartbeat_interval=0.2)
        self.assertTrue(started)
        self.assertTrue(st.session_active)
        self.assertEqual(st.frame_seq, 10)

        # 2. Send full frame using 768-byte bytes object (as in handoff doc)
        raw_red = bytes([255, 0, 0] * 256)
        ok_frame = st.send_full_frame(raw_red, auto_mode=True)
        self.assertTrue(ok_frame)
        self.assertEqual(st.frame_seq, 11)
        self.assertTrue(st.is_committed)
        self.assertTrue(st.is_displayed)

        # 3. Stop session
        stopped = st.stop()
        self.assertTrue(stopped)
        self.assertFalse(st.session_active)

    def test_streamer_start_failure_rejected(self):
        from canvas_stream import CanvasStreamer

        class FailingTransport:
            def send_line(self, line, wait_reply=True, timeout=1.0):
                return {"status": "error", "error": "session_rejected", "active": False}

        st = CanvasStreamer(FailingTransport())
        started = st.start(session_id="fail_sess")
        self.assertFalse(started)
        self.assertFalse(st.session_active)

    def test_send_full_frame_accepts_bytes_and_list(self):
        from canvas_stream import CanvasStreamer

        class EchoTransport:
            def send_raw_with_ack(self, pkt, expected_frame_seq, timeout=1.0):
                return {"status": "ok", "type": "bin_frame", "frame_id": expected_frame_seq, "committed": True, "displayed": True}

        st = CanvasStreamer(EchoTransport())
        # A. bytes of length 768
        self.assertTrue(st.send_full_frame(b"\x10" * 768))

        # B. list of 256 RGB tuples
        self.assertTrue(st.send_full_frame([(10, 20, 30)] * 256))

        # C. list of 768 ints
        self.assertTrue(st.send_full_frame([42] * 768))

        # D. invalid size raises ValueError
        with self.assertRaises(ValueError):
            st.send_full_frame(b"\x00" * 100)

    def test_strict_displayed_flag_no_inference(self):
        from canvas_stream import CanvasStreamer

        class NoDisplayedReplyTransport:
            def send_raw_with_ack(self, pkt, expected_frame_seq, timeout=1.0):
                # Returns status ok and committed True, but OMITS displayed!
                return {"status": "ok", "type": "bin_frame", "frame_id": expected_frame_seq, "committed": True}

        st = CanvasStreamer(NoDisplayedReplyTransport())
        # With require_displayed=True, must return False because displayed was not explicitly confirmed
        displayed_ok = st.send_full_frame(b"\x10" * 768, require_displayed=True)
        self.assertFalse(displayed_ok)
        self.assertFalse(st.is_displayed)
        self.assertTrue(st.is_committed)

    def test_stop_auto_releases_arcade_keys(self):
        from canvas_stream import CanvasStreamer

        sent_commands = []
        class CommandCollectorTransport:
            def send_line(self, cmd, wait_reply=True, timeout=1.0):
                sent_commands.append(cmd)
                return {"status": "ok", "active": False}

        st = CanvasStreamer(CommandCollectorTransport())
        st.session_active = True
        ok = st.stop()
        self.assertTrue(ok)
        self.assertFalse(st.session_active)
        # Verify arcade input down=0 was sent prior to or along with session stop
        arcade_released = any('"cmd": "arcade"' in c and '"down": 0' in c for c in sent_commands)
        self.assertTrue(arcade_released)

    def test_heartbeat_consecutive_failures_deactivates_session(self):
        import time
        from canvas_stream import CanvasStreamer

        call_count = 0
        class FailingHeartbeatTransport:
            def send_line(self, cmd, wait_reply=True, timeout=1.0):
                nonlocal call_count
                if '"cmd": "session"' in cmd and '"action": "start"' in cmd:
                    return {"status": "ok", "active": True}
                if '"action": "heartbeat"' in cmd or '"action": "ping"' in cmd:
                    call_count += 1
                    return {"status": "error", "error": "session_expired", "active": False}
                return {"status": "ok"}

        st = CanvasStreamer(FailingHeartbeatTransport())
        st.start(session_id="hb_fail_test", heartbeat_interval=0.05, timeout=0.1)
        self.assertTrue(st.session_active)

        # Wait for 3 heartbeat iterations (approx 0.2s)
        time.sleep(0.3)
        self.assertFalse(st.session_active)
        self.assertFalse(st.heartbeat_alive)
        self.assertGreaterEqual(call_count, 3)
        st.stop()


if __name__ == "__main__":
    unittest.main()
